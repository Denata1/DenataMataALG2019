
package project;

import java.io.IOException;
import static project.WebCrawler.Algorithem;
import static project.WebCrawler.showResults;


public class Project {

  
    public static void main(String[] args) {
       try{
           Algorithem("https://en.wikipedia.org/wiki/Granit_Xhaka");
           showResults();
           
    }catch(IOException e){
    }
    
}
}
